CREATE DATABASE BD_loja_virtual;
USE BD_loja_virtual;

CREATE TABLE categorias (
    idcategorias INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    categoria_prod VARCHAR(45) NULL,
    descricao VARCHAR(45) NULL
);

CREATE TABLE produto (
    idproduto INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nome_prod VARCHAR(45) NULL,
    preco_prod DECIMAL(6,2) NULL,
    qtd_prod INT NULL,
    FK_CATEGORIAS INT
);